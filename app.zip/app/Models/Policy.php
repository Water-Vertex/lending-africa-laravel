<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Policy extends Model
{
    protected $fillable = ['title', 'slug', 'content', 'status'];

    protected $casts = [
        'status' => 'boolean',
    ];
}