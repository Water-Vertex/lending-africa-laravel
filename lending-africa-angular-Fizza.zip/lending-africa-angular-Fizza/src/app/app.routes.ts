import { Routes } from '@angular/router';

import { Login } from './components/auth/login/login';
import { Logout } from './components/auth/logout/logout';

import { AdminLayout } from './components/admin/layouts/admin-layout/admin-layout';
import { Dashboard } from './components/admin/pages/dashboard/dashboard';

import { LoanProductList } from './components/admin/pages/loan-products/loan-products-list/loan-products-list';
import { LoanProductForm } from './components/admin/pages/loan-products/loan-products-add/loan-products-add';

import { authGuard } from './guards/auth-guard';

export const routes: Routes = [

  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },

  {
    path: 'login',
    component: Login
  },

  {
    path: 'logout',
    component: Logout
  },

  {
    path: 'admin',
    component: AdminLayout,
    canActivate: [authGuard],
    children: [

      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },

      {
        path: 'dashboard',
        component: Dashboard
      },

      // Loan Products routes
      { path: 'loan-products/list', component: LoanProductList },
      { path: 'loan-products/add', component: LoanProductForm },
      { path: 'loan-products/edit/:id', component: LoanProductForm }

    ]
  },

  {
    path: '**',
    redirectTo: 'login'
  }

];